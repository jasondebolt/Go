
Flask-S3
-------------

Easily serve your static files from Amazon S3.


